package br.com.livros.principal;

import java.util.Scanner;

import br.com.livros.DAO.LivroDAO;
import br.com.livros.beans.LivroBeans;

public class TesteAdicionarLivros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LivroDAO dao = null;
		try {
			System.out.println("----MENU-------");
			System.out.println("1 - Adicionar Livro");
			System.out.println("2 - Consultar livros");
			dao = new LivroDAO();
			int menu = 0;
			Scanner scn = new Scanner(System.in);
			LivroBeans ben = new LivroBeans();
			menu = scn.nextInt();
			if (menu == 1) {

				System.out.println("Informe o id");
				ben.setId(scn.nextInt());
				System.out.println("Nome do autor: ");
				ben.setNome_autor(scn.next());
				System.out.println("Nome do livro: ");
				ben.setNome_livro(scn.next());
				System.out.println("valor: ");
				ben.setValor(scn.nextDouble());
				System.out.println("isb: ");
				ben.setIsbn(scn.nextInt());

				dao.Addlivro(ben);
			}
			
			if (menu == 2) {
				LivroBeans c = dao.getLivro(1);
				System.out.println(c.getNome_autor());
				//System.out.println(dao.getLivro(ben.getValor()));

			


			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				dao.encerrar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
