package br.com.livros.conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
	
	public static Connection goConnect() throws Exception{
		return DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL","rm82970", "171299");
		
	}

}
