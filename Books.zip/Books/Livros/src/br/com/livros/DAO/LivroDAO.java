package br.com.livros.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.livros.beans.LivroBeans;
import br.com.livros.conexao.Conexao;


public class LivroDAO {
	
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public LivroDAO() throws Exception{
		con = Conexao.goConnect();
	}
	
	public int Addlivro (LivroBeans l ) throws Exception {
		stmt = con.prepareStatement("INSERT INTO RW_T_LIVROS (id_livro,nm_livro,nr_isbn,nm_autor,vl_livro)"
				+ "values (?,?,?,?,?)");
		stmt.setInt(1, l.getId());
		stmt.setString(2, l.getNome_livro());
		stmt.setInt(3, l.getIsbn());
		stmt.setString(4, l.getNome_autor());
		stmt.setDouble(5, l.getValor());
		
		return stmt.executeUpdate();
	}
	public LivroBeans getLivro(int codAss) throws Exception {
		stmt = con.prepareStatement("select * from RW_T_LIVROS where id_livro =?");
		stmt.setInt(1, codAss);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new LivroBeans(rs.getInt("id_livro"), rs.getString("nm_livro"), rs.getInt("nr_isbn"), rs.getString("nm_autor"), rs.getDouble("vl_livro"));
		} else {
			return new LivroBeans();
		}
	}
	public void encerrar() throws Exception{
		con.close();
	}

}
