package br.com.livros.beans;

public class LivroBeans {
	private int id;
	private String nome_livro;
	private int isbn;
	private String nome_autor;
	private double valor;
	
	
	public LivroBeans(int id, String nome_livro, int isbn, String nome_autor, double valor) {
		super();
		this.id = id;
		this.nome_livro = nome_livro;
		this.isbn = isbn;
		this.nome_autor = nome_autor;
		this.valor = valor;
	}
	
	public LivroBeans() {
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome_livro() {
		return nome_livro;
	}
	public void setNome_livro(String nome_livro) {
		this.nome_livro = nome_livro;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getNome_autor() {
		return nome_autor;
	}
	public void setNome_autor(String nome_autor) {
		this.nome_autor = nome_autor;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	

}
