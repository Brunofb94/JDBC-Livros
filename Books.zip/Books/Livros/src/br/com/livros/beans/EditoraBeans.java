package br.com.livros.beans;

public class EditoraBeans {
	
	private int id;
	private String nomr_editora;
	private int telefone;
	private String email;
	
	
	public EditoraBeans(int id, String nomr_editora, int telefone, String email) {
		super();
		this.id = id;
		this.nomr_editora = nomr_editora;
		this.telefone = telefone;
		this.email = email;
	}
	public EditoraBeans() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNomr_editora() {
		return nomr_editora;
	}
	public void setNomr_editora(String nomr_editora) {
		this.nomr_editora = nomr_editora;
	}
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
